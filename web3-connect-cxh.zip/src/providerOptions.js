import WalletConnect from "@walletconnect/web3-provider";
import CoinbaseWalletSDK from "@coinbase/wallet-sdk";

export const providerOptions = {
  walletlink: {
    package: CoinbaseWalletSDK, 
    options: {
      appName: "CoinXHub", 
      infuraId: "ab44242bb6424aceadbe394c3f6730b7"
    }
  },
  walletconnect: {
    package: WalletConnect, 
    options: {
      infuraId: "ab44242bb6424aceadbe394c3f6730b7"
    }
  }
};
